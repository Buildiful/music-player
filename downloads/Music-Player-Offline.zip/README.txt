Music Player by Buildiful®

Open index.html in your browser. No server or installation needed. Audio files remain local; browser storage availability for file:// pages varies, so a temporary session may be used. For reliable offline persistence, install the PWA from its HTTPS site.
